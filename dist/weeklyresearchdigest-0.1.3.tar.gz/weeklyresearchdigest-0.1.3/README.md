# WeeklyResearchDigest

A Python package for automating the retrieval, summarization, and emailing of weekly research updates.
